//
// Created by x0lotl on 9/14/22.
//
#pragma once

double sum(int number, double x);