//
// Created by x0lotl on 9/15/22.
//

#pragma once

int greatest_common_denominator_loop(int m, int n);

int greatest_common_denominator_recursive(int m, int n);
