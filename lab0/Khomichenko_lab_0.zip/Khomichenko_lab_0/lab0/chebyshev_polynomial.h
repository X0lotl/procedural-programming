//
// Created by x0lotl on 9/15/22.
//

#pragma once

int chebyshev_polynomial(int n, int x);