//
// Created by x0lotl on 9/15/22.
//

#pragma once

unsigned int division(unsigned int m,unsigned int n);