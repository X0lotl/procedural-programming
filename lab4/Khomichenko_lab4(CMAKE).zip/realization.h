//
// Created by x0lotl on 10/23/22.
//
#pragma once

double M (double a, double b);