//
// Created by x0lotl on 19.11.22.
//

#pragma once
int quickFibNumber(int fibNumber, int &counter);
