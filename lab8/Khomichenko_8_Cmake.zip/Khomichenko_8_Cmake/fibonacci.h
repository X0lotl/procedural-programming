//
// Created by x0lotl on 20.11.22.
//

#pragma once

double Fibonaci(unsigned int n, int &counter);
