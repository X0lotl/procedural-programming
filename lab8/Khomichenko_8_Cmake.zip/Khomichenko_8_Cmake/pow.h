//
// Created by x0lotl on 20.11.22.
//
#pragma once
double power(double x, unsigned int n, int &counter);