//
// Created by x0lotl on 09.11.22.
//

#pragma once

int quickFib(int fibNumber);